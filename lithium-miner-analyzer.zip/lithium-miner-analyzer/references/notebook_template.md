# Notebook Template Reference

Use this as the base pattern for building the notebook with `nbformat`.

## Python Skeleton

```python
import nbformat
from nbformat.v4 import new_notebook, new_markdown_cell, new_code_cell

nb = new_notebook()
nb.metadata = {
    "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
    "language_info": {"name": "python", "version": "3.10.0"}
}
cells = []

def md(text):
    cells.append(new_markdown_cell(text))

def code(src):
    cells.append(new_code_cell(src))
```

---

## Cell 0 — Imports & Config

```python
# ═══════════════════════════════════════════════════════════════
#  LITHIUM MINER ANALYSIS — [COMPANY NAME] ([TICKER])
#  Built by Claude · Edit the variables below to customise
# ═══════════════════════════════════════════════════════════════

import pandas as pd
import numpy as np
import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import warnings
warnings.filterwarnings('ignore')

# ── COMPANY ──────────────────────────────────────────────────────
COMPANY_NAME   = "[Company Name]"
TICKER         = "[TICKER]"
SHARES_OUT_M   = 0       # million shares outstanding — fill in
CURRENT_PRICE  = 0.0     # USD/share — fill in
NET_DEBT_USD_M = 0       # net debt in USD millions

# ── LITHIUM PRICE ASSUMPTIONS (USD / tonne LCE) ──────────────────
LIVE_PRICE_LCE  = 14_500  # fetched at build time
PRICE_BEAR      = 10_000
PRICE_BASE      = 15_000  # ← primary assumption; edit me
PRICE_BULL      = 25_000

# ── DISCOUNT RATE & TAX ──────────────────────────────────────────
WACC             = 0.10
TERMINAL_GROWTH  = 0.02

# ── DCF HORIZON ──────────────────────────────────────────────────
START_YEAR       = 2024
FORECAST_YEARS   = 15

# ── CORPORATE G&A (USD millions per year) ────────────────────────
GA_BASE_USD_M    = 30

print("✅ Config loaded. Edit variables above and re-run to update all outputs.")
```

---

## Section 1 — Macro Demand Chart Template

```python
# Macro lithium demand by sector (ktpa LCE) — edit values from research
years = list(range(2023, 2036))

demand_data = {
    "Passenger EVs":       [350, 420, 510, 610, 720, 840, 970, 1100, 1240, 1380, 1520, 1650, 1780],
    "Commercial EVs":      [ 40,  55,  72,  92, 115, 140, 168,  198,  230,  262,  295,  328,  360],
    "Grid Storage":        [ 80, 110, 150, 200, 260, 330, 410,  500,  600,  710,  830,  960, 1100],
    "Consumer Electronics":[ 95,  98, 100, 102, 103, 104, 105,  106,  107,  108,  109,  110,  110],
    "Other Industrial":    [ 50,  54,  58,  63,  68,  73,  79,   85,   91,   97,  104,  111,  118],
}

df_demand = pd.DataFrame(demand_data, index=years)

fig = go.Figure()
colors = ['#2196F3','#4CAF50','#FF9800','#9C27B0','#F44336']
for i, col in enumerate(df_demand.columns):
    fig.add_trace(go.Scatter(
        x=years, y=df_demand[col], name=col,
        stackgroup='one', fillcolor=colors[i], line=dict(color=colors[i])
    ))

fig.update_layout(
    title="Global Lithium Demand by Sector (ktpa LCE)",
    xaxis_title="Year", yaxis_title="ktpa LCE",
    hovermode="x unified", template="plotly_white",
    legend=dict(orientation="h", y=-0.2)
)
fig.show()

# Supply/demand balance
supply = [700, 780, 870, 980, 1100, 1230, 1370, 1510, 1660, 1820, 1970, 2100, 2230]  # EDIT
total_demand = df_demand.sum(axis=1).values
deficit = total_demand - supply

fig2 = go.Figure()
fig2.add_bar(x=years, y=supply, name="Supply", marker_color='steelblue')
fig2.add_bar(x=years, y=total_demand, name="Demand", marker_color='coral')
fig2.add_trace(go.Scatter(x=years, y=deficit, name="Deficit/Surplus", 
                          line=dict(color='red', width=2, dash='dot'), yaxis='y2'))
fig2.update_layout(
    title="Lithium Supply vs Demand Balance",
    barmode='group', template="plotly_white",
    yaxis2=dict(overlaying='y', side='right', title='Deficit (ktpa)')
)
fig2.show()
```

---

## Section 3 — Gantt Chart Template

```python
# Mine production timeline Gantt
import plotly.figure_factory as ff

gantt_data = []
for mine_name, m in mines.items():
    if m['first_production_year'] > 0:
        start = f"{m['first_production_year']}-01-01"
        end_year = m['first_production_year'] + m['mine_life_years']
        end = f"{end_year}-01-01"
        gantt_data.append(dict(
            Task=mine_name,
            Start=start,
            Finish=end,
            Resource=m['type']
        ))

colors_gantt = {'hard_rock': 'rgb(33, 150, 243)', 'brine': 'rgb(76, 175, 80)', 'clay': 'rgb(255, 152, 0)'}
fig_gantt = ff.create_gantt(gantt_data, colors=colors_gantt, index_col='Resource',
                             show_colorbar=True, group_tasks=True,
                             title=f"{COMPANY_NAME} — Mine Production Timeline")
fig_gantt.show()
```

---

## Section 5 — Mine P&L Loop Template

```python
def model_mine(mine_name, mine, price_lce, years_range):
    """Returns annual P&L DataFrame for a single mine."""
    rows = []
    for yr_offset, year in enumerate(years_range):
        years_since_start = year - mine['first_production_year']
        if years_since_start < 0 or years_since_start >= mine['mine_life_years']:
            production = 0
        elif years_since_start < mine['ramp_years']:
            ramp_frac = (years_since_start + 1) / mine['ramp_years']
            production = mine['nameplate_capacity_ktpa'] * ramp_frac
        else:
            production = mine['nameplate_capacity_ktpa']

        production_owned = production * mine['ownership_pct'] / 100
        revenue = production_owned * price_lce / 1000  # USD millions (price is per tonne, prod is ktpa)
        opex = production_owned * mine['aisc_usd_t'] / 1000
        royalties = revenue * mine['royalty_pct'] / 100
        sustaining_capex = mine['capex_sustaining_annual_usdm'] if production > 0 else 0
        ebitda = revenue - opex - royalties
        depletion = (mine['capex_remaining_usdm'] / mine['mine_life_years']) if mine['capex_remaining_usdm'] > 0 else 0
        ebit = ebitda - depletion - sustaining_capex
        tax = max(0, ebit * mine['tax_rate'])
        fcf = ebit - tax + depletion  # add back non-cash depletion

        rows.append({
            'year': year, 'mine': mine_name,
            'production_ktpa': production_owned,
            'revenue_usdm': revenue, 'opex_usdm': opex,
            'royalties_usdm': royalties, 'ebitda_usdm': ebitda,
            'sustaining_capex_usdm': sustaining_capex,
            'ebit_usdm': ebit, 'tax_usdm': tax, 'fcf_usdm': fcf
        })
    return pd.DataFrame(rows)
```

---

## Section 6 — Waterfall Chart Template

```python
def waterfall_chart(year, consolidated_df, title_suffix="Base Case"):
    row = consolidated_df[consolidated_df['year'] == year].iloc[0]
    labels = ['Revenue', 'AISC Costs', 'Royalties', 'EBITDA', 'Sustaining Capex', 
              'Depletion/D&A', 'EBIT', 'Tax', 'Net Income / FCF']
    
    revenue = row['revenue_usdm']
    costs = -row['opex_usdm']
    royalties = -row['royalties_usdm']
    ebitda = row['ebitda_usdm']
    sust = -row['sustaining_capex_usdm']
    dda = -row.get('dda_usdm', 0)
    ebit = row['ebit_usdm']
    tax = -row['tax_usdm']
    fcf = row['fcf_usdm']
    
    fig = go.Figure(go.Waterfall(
        name="P&L Bridge", orientation="v",
        measure=["absolute", "relative", "relative", "total", 
                 "relative", "relative", "total", "relative", "total"],
        x=labels,
        y=[revenue, costs, royalties, ebitda, sust, dda, ebit, tax, fcf],
        connector={"line": {"color": "rgb(63, 63, 63)"}},
        increasing={"marker": {"color": "#4CAF50"}},
        decreasing={"marker": {"color": "#F44336"}},
        totals={"marker": {"color": "#2196F3"}}
    ))
    fig.update_layout(title=f"{COMPANY_NAME} P&L Bridge — {year} ({title_suffix})",
                      yaxis_title="USD Millions", template="plotly_white")
    fig.show()
```

---

## Section 7 — DCF Template

```python
def dcf_valuation(price_lce, label="Base"):
    years_range = list(range(START_YEAR, START_YEAR + FORECAST_YEARS))
    
    # Aggregate FCFs across all mines
    all_mine_fcfs = []
    for mine_name, mine in mines.items():
        df_mine = model_mine(mine_name, mine, price_lce, years_range)
        all_mine_fcfs.append(df_mine.set_index('year')['fcf_usdm'])
    
    total_fcf = pd.concat(all_mine_fcfs, axis=1).sum(axis=1)
    total_fcf -= GA_BASE_USD_M  # corporate G&A
    
    # Discount
    discount_factors = [(1 + WACC) ** -(i+1) for i in range(FORECAST_YEARS)]
    pv_fcfs = total_fcf.values * discount_factors
    
    # Terminal value
    terminal_fcf = total_fcf.iloc[-1] * (1 + TERMINAL_GROWTH)
    terminal_value = terminal_fcf / (WACC - TERMINAL_GROWTH)
    pv_terminal = terminal_value * discount_factors[-1]
    
    enterprise_value = sum(pv_fcfs) + pv_terminal
    equity_value = enterprise_value - NET_DEBT_USD_M
    nav_per_share = equity_value / SHARES_OUT_M if SHARES_OUT_M > 0 else 0
    p_nav = CURRENT_PRICE / nav_per_share if nav_per_share > 0 else 0
    
    return {
        'scenario': label, 'price_lce': price_lce,
        'enterprise_value_usdm': round(enterprise_value, 1),
        'equity_value_usdm': round(equity_value, 1),
        'nav_per_share': round(nav_per_share, 2),
        'p_nav': round(p_nav, 2),
        'pv_fcfs': pv_fcfs,
        'pv_terminal': pv_terminal,
        'years': years_range
    }

results = {
    'bear': dcf_valuation(PRICE_BEAR, "Bear"),
    'base': dcf_valuation(PRICE_BASE, "Base"),
    'bull': dcf_valuation(PRICE_BULL, "Bull"),
}

# Summary table
summary = pd.DataFrame([v for v in results.values() if isinstance(v, dict)])
print(summary[['scenario','price_lce','enterprise_value_usdm','nav_per_share','p_nav']].to_string(index=False))
```

---

## Section 7b — Sensitivity Table

```python
# NPV sensitivity: WACC vs Lithium Price
wacc_range = [0.08, 0.09, 0.10, 0.11, 0.12, 0.13, 0.14]
price_range = [10000, 12500, 15000, 17500, 20000, 22500, 25000]

matrix = []
for w in wacc_range:
    row_vals = []
    for p in price_range:
        original_wacc = WACC
        WACC = w
        res = dcf_valuation(p, "sens")
        WACC = original_wacc
        row_vals.append(round(res['enterprise_value_usdm'], 0))
    matrix.append(row_vals)

df_sens = pd.DataFrame(matrix, index=[f"{int(w*100)}%" for w in wacc_range],
                        columns=[f"${int(p/1000)}k" for p in price_range])

fig = px.imshow(df_sens, text_auto=True, color_continuous_scale='RdYlGn',
                title="Enterprise Value (USD M) — WACC vs Li Price Sensitivity",
                labels=dict(x="Lithium Price (USD/t LCE)", y="WACC", color="EV (USDm)"))
fig.show()
```

---

## Notebook Finalisation

```python
nb.cells = cells

with open(f"/home/claude/{ticker}_lithium_analysis.ipynb", "w") as f:
    nbformat.write(nb, f)

print(f"✅ Notebook saved: {ticker}_lithium_analysis.ipynb")
```
