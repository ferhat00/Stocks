# Lithium Market Context

Static reference data for the lithium miner analyzer. Use this to ground assumptions
when public data is unavailable for the specific miner under analysis.

---

## Lithium Product Types & Conversion Factors

| Product | Conversion to LCE | Notes |
|---|---|---|
| Spodumene concentrate (6% Li₂O) | 1 tonne SC6 ≈ 0.22t LCE | Hard rock, Australia dominant |
| Lithium carbonate (Li₂CO₃) | 1:1 with LCE | Brine dominant, Chile/Argentina |
| Lithium hydroxide (LiOH·H₂O) | 1t LiOH ≈ 0.88t LCE | Premium product, used in NMC811 |
| Lithite ore (hard rock, % Li) | % Li × 5.32 = % LCE | Raw ore conversion |

**LCE (Lithium Carbonate Equivalent)** is the industry standard unit for comparing
different lithium products.

---

## Typical AISC Ranges by Deposit Type (2023–2024 USD/t LCE)

| Type | Low-cost | Mid | High-cost |
|---|---|---|---|
| Brine (Chile, Argentina) | $3,000–5,000 | $5,000–8,000 | $8,000–12,000 |
| Hard rock spodumene (Australia) | $4,000–6,000 | $6,000–9,000 | $9,000–14,000 |
| Clay / other | $8,000–12,000 | $12,000–18,000 | $18,000+ |

Note: AISC = All-In Sustaining Cost. Includes mining, processing, G&A, royalties, sustaining capex.
Excludes growth capex and corporate finance costs.

---

## Royalty Norms by Jurisdiction

| Country / Region | Typical Royalty |
|---|---|
| Australia (State royalties) | 2.5–5% of revenue (WA: 5% for spodumene) |
| Chile | 3% of sales (CORFO contract terms vary) |
| Argentina | 3% provincial; varies by province |
| Canada | 1–3% of revenue (Crown royalties) |
| USA (Nevada) | 5% net smelter return typical |
| Zimbabwe | 2% of gross revenue |
| DRC | 3.5% of turnover |
| Portugal | Negotiated; typically 2–4% |

---

## Tax Rates by Major Jurisdiction (2024)

| Country | Corporate Tax Rate | Notes |
|---|---|---|
| Australia | 30% | Large companies; 25% for SMEs |
| Chile | 27% | + specific mining tax (0.5–14% sliding scale) |
| Argentina | 35% | + provincial taxes |
| Canada | 26.5% | Federal + provincial; varies |
| USA | 21% | Federal; state tax additional |
| Zimbabwe | 25% | + royalties |
| Portugal | 21% | |
| Bolivia | 25% | |

---

## Lithium Price History & Benchmarks (USD/t LCE)

| Period | Carbonate (CIF China) | Hydroxide (CIF China) |
|---|---|---|
| 2018 average | ~$13,000 | ~$16,000 |
| 2020 trough | ~$6,500 | ~$8,000 |
| 2022 peak | ~$80,000 | ~$85,000 |
| 2023 average | ~$30,000 | ~$35,000 |
| H1 2024 | ~$13,000–16,000 | ~$12,000–14,000 |

**Key price drivers:** Chinese EV demand, inventory cycles, Australian and Chilean supply,
new brine projects in Argentina, battery chemistry shift (NMC vs LFP).

---

## Analyst Consensus Price Forecasts (as of mid-2024)

| House | 2025 | 2026 | 2027 | Long-run |
|---|---|---|---|---|
| Goldman Sachs | $11,000 | $13,000 | $15,000 | $17,000 |
| Morgan Stanley | $12,500 | $14,000 | $16,500 | $18,000 |
| Wood Mackenzie | $13,000 | $16,000 | $19,000 | $20,000 |
| BloombergNEF | $14,000 | $17,000 | $20,000 | $22,000 |
| Benchmark Mineral | $15,000 | $19,000 | $23,000 | $25,000 |

Use midpoint of range for base case. Discount by 15–20% for bear, premium of 30–50% for bull.

---

## Demand Growth Benchmarks (ktpa LCE)

Global demand estimates from IEA Global EV Outlook 2024 and BloombergNEF:

| Year | Base case | Bear | Bull |
|---|---|---|---|
| 2024 | ~700 | ~620 | ~780 |
| 2026 | ~950 | ~800 | ~1,150 |
| 2028 | ~1,250 | ~1,000 | ~1,600 |
| 2030 | ~1,600 | ~1,200 | ~2,100 |
| 2035 | ~2,500 | ~1,700 | ~3,500 |

EV sector accounts for ~65–70% of demand by 2030; grid storage growing fastest.

---

## Comparable Peer Miners (reference list — verify current data)

| Company | Ticker | Domicile | Type | Scale |
|---|---|---|---|---|
| Albemarle | ALB (NYSE) | USA | Hard rock + brine | Large |
| SQM | SQM (NYSE) | Chile | Brine | Large |
| Arcadium Lithium | ALTM (NYSE) | Australia/USA | Mixed | Large |
| Pilbara Minerals | PLS (ASX) | Australia | Hard rock | Mid |
| Allkem (now Arcadium) | AKE (ASX) | Australia | Mixed | Mid |
| Core Lithium | CXO (ASX) | Australia | Hard rock | Small |
| Sigma Lithium | SGML (NASDAQ) | Brazil | Hard rock | Small-mid |
| Ganfeng Lithium | 1772 (HKEX) | China | Mixed | Large |
| Tianqi Lithium | 9696 (HKEX) | China | Hard rock | Large |
| Livent (now Arcadium) | LTHM (NYSE) | USA | Brine | Mid |
| Liontown Resources | LTR (ASX) | Australia | Hard rock | Small-mid |
| Patriot Battery Metals | PMET (TSX) | Canada | Hard rock | Early stage |

---

## NI 43-101 / JORC Resource Classification

Resources and reserves use these classifications under JORC (Australia) or NI 43-101 (Canada):

**Resources** (ascending confidence): Inferred → Indicated → Measured  
**Reserves** (derived from resources): Probable (from Indicated) → Proven (from Measured)

Only Proved + Probable Reserves can be used in mine planning and DCF.
Inferred resources carry high uncertainty — treat as upside option value only.

---

## EV Demand Context

Key facts to cite in the macro section:
- Global EV sales 2023: ~14 million units; projected 2030: ~40–50 million
- Average lithium content: ~8–10 kg Li per EV (varies: LFP ~6kg, NMC ~10kg)
- Battery gigafactory pipeline: >6 TWh of announced capacity globally through 2030
- Grid storage deployed 2023: ~42 GWh; projected 2030: >400 GWh (IEA)
- LFP (lithium iron phosphate) gaining share in China; NMC still dominant in West
- China accounts for ~60% of global lithium demand
