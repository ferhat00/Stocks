---
name: lithium-miner-analyzer
description: >
  Comprehensive lithium miner investment analysis skill. Use this skill whenever a user
  names a specific lithium mining company and wants financial analysis, DCF valuation,
  mine production analysis, or investment research. Triggers on requests like "analyse
  [Company] as a lithium investment", "build a DCF for [miner]", "research [company]
  lithium production", "is [company] a good buy", "model [miner] cash flows", or any
  request combining a company name with lithium, mining, valuation, or investment analysis.
  Also triggers when user uploads investor presentations, annual reports, or NI 43-101
  technical reports from a lithium miner. Output is always a fully interactive Jupyter
  Notebook with tunable parameters.
---

# Lithium Miner Analyzer

Produces a self-contained, interactive Jupyter Notebook that covers macro lithium demand,
mine-by-mine production schedules, advanced DCF valuation, and rich visualisations.

## Workflow Overview

1. **Identify the miner** from user input
2. **Gather data** (web research + any uploaded documents)
3. **Build the notebook** section by section using the template in `references/notebook_template.md`
4. **Save and present** the `.ipynb` file

---

## Step 1 — Identify Miner & Collect Inputs

Ask the user (if not already stated):
- Which miner? (ticker + exchange preferred, e.g. PLS.AX, ALB, SQM)
- Any uploaded files? (investor decks, NI 43-101 reports, annual reports)

If files are uploaded, they will be at `/mnt/user-data/uploads/`. Read them with `view` or extract text with `pdftotext`.

---

## Step 2 — Data Gathering

Run research in parallel across these areas. Use `web_search` and `web_fetch` throughout.

### 2a. Macro Lithium Demand
Search for current data on:
- Global EV adoption forecasts (IEA, BloombergNEF, Wood Mackenzie) — passenger + commercial
- Grid-scale battery storage deployment (GWh by year)
- Consumer electronics, industrial, aerospace demand
- Lithium supply/demand balance and deficit forecasts
- Analyst consensus on lithium carbonate equivalent (LCE) demand through 2035

Key search queries to use:
```
lithium demand forecast 2024 2030 EV battery storage IEA BloombergNEF
global lithium carbonate equivalent demand supply deficit 2025 2030
lithium price forecast 2024 bull bear base case analyst consensus
```

### 2b. Miner-Specific Research
Search for:
- Company overview, market cap, listing exchange
- All operating mines: name, location, type (hard rock spodumene / brine / clay), ownership %, resource/reserve size (Mt @ Li%), current production rate (ktpa LCE), AISC
- Development projects: stage (PFS/DFS/construction/commissioning), expected first production date, nameplate capacity, capex estimate
- Recent financial results: revenue, EBITDA, net income, FCF, cash, debt
- Royalty obligations, streaming deals, offtake agreements
- Tax jurisdiction rates for each mine location
- Management guidance and analyst price targets

Key search queries:
```
[COMPANY NAME] annual report 2023 2024 production guidance
[COMPANY NAME] mine operations lithium production capacity AISC
[COMPANY NAME] investor presentation 2024 development projects
[COMPANY NAME] ASX/NYSE announcement resource reserve estimate
[COMPANY NAME] peers comparable lithium producers market cap
```

If investor presentations are found, use `web_fetch` to retrieve them. Parse for:
- Slide data: production ramp timelines, cost curves, capex schedules
- Reserve/resource tables
- Financial summaries

### 2c. Live Lithium Spot Price
Try to fetch current lithium carbonate / hydroxide prices:
```
lithium carbonate price today 2024 USD per tonne spot
lithium hydroxide price spot market China CIF
```
Fallback price assumptions if live data unavailable:
- Bear: $10,000/t LCE
- Base: $15,000/t LCE  
- Bull: $25,000/t LCE

### 2d. Peer Comparison
Identify 3–5 comparable miners by size/stage. For each, collect:
market cap, EV, production (ktpa LCE), EV/EBITDA, P/NAV, AISC, growth pipeline.

---

## Step 3 — Build the Jupyter Notebook

Install dependencies first:
```bash
pip install jupyter nbformat pandas numpy matplotlib plotly ipywidgets scipy --break-system-packages -q
```

Build the notebook programmatically using `nbformat`. Save to `/home/claude/[company_name]_analysis.ipynb`.

Structure the notebook with these sections in order. Full cell templates are in `references/notebook_template.md` — read that file now before writing any cells.

### Notebook Sections

**Section 0: Setup & Configuration** *(code cell)*
All tunable parameters as clearly labelled variables at the top:
```python
# ── LITHIUM PRICE ASSUMPTIONS (USD / tonne LCE) ──────────────────
PRICE_BEAR   = 10_000
PRICE_BASE   = 15_000   # ← edit me
PRICE_BULL   = 25_000
LIVE_PRICE   = 14_500   # fetched at build time, override above

# ── DISCOUNT RATE & TAX ──────────────────────────────────────────
WACC         = 0.10
TAX_RATE     = 0.27     # jurisdiction-specific; override per mine below

# ── DCF HORIZON ──────────────────────────────────────────────────
FORECAST_YEARS = 15
TERMINAL_GROWTH = 0.02
```

**Section 1: Macro Demand** *(markdown + code + charts)*
- Narrative on lithium demand drivers
- DataFrame of demand by sector (EVs, trucks, storage, other) by year 2024–2035
- Stacked area chart: EV adoption curves by region (using plotly)
- Bar chart: battery storage demand in GWh
- Supply/demand balance chart with deficit highlighted

**Section 2: Company Overview** *(markdown + code)*
- Company profile: ticker, exchange, market cap, headquarters, key management
- Summary stats table: total resources (Mt LCE), total reserves, current production (ktpa), guidance

**Section 3: Mine-by-Mine Breakdown** *(markdown + code + charts)*
For each mine/project:
```python
mines = {
    "Mine Name": {
        "type": "hard_rock",          # hard_rock | brine | clay
        "ownership_pct": 100,
        "resource_mt_lce": 2.5,
        "reserve_mt_lce": 1.2,
        "current_production_ktpa": 80,
        "nameplate_capacity_ktpa": 120,
        "first_production_year": 2024,
        "ramp_years": 2,              # years to reach nameplate
        "mine_life_years": 20,
        "aisc_usd_t": 6500,
        "capex_remaining_usdm": 0,
        "capex_sustaining_annual_usdm": 15,
        "royalty_pct": 2.5,
        "tax_rate": 0.30,
        "country": "Australia",
    },
    # ... repeat for each mine/project
}
```
- Gantt chart: production timeline per mine (start → nameplate → depletion)
- Bar chart: capacity by mine at nameplate, coloured by type

**Section 4: Consolidated Production Model** *(code)*
- Aggregate production schedule across all mines year by year
- Revenue = production × price (calculate for all three scenarios)
- Line chart: production ramp with scenario shading

**Section 5: Mine-Level P&L & Cost Model** *(code)*
For each mine, by year:
- Revenue (ownership-adjusted)
- AISC-based operating costs
- Royalties
- Sustaining capex
- Mine EBITDA, EBIT (post depletion/amortisation)
- Tax
- Free cash flow contribution

**Section 6: Consolidated P&L** *(code)*
- Corporate G&A overlay
- Group EBITDA, EBIT, Net Income, FCF
- Waterfall chart: revenue → EBITDA → EBIT → Net Income → FCF (for base case year 3)

**Section 7: DCF Valuation** *(code)*
```python
def dcf_valuation(scenario="base"):
    # project FCFs year by year
    # terminal value = FCF_final × (1 + g) / (WACC - g)
    # discount all to PV
    # return NPV, implied share price, P/NAV
```
- Sensitivity table: NPV vs WACC (8–14%) × lithium price ($10k–$30k)
- Tornado chart: which assumptions drive value most

**Section 8: Scenario Summary** *(code)*
Side-by-side table: Bear / Base / Bull
- NPV, equity value, implied share price, upside/downside vs current price
- IRR by mine

**Section 9: Peer Comparison** *(code)*
- Table: EV, market cap, production, EV/EBITDA, P/NAV, AISC vs peers
- Scatter plot: EV/EBITDA vs growth (bubble size = production)

**Section 10: Investment Thesis & Risks** *(markdown)*
- Bull case summary
- Bear case / key risks (lithium price, permitting, execution, FX, water rights)
- Key catalysts to watch

---

## Step 4 — Finalise & Present

After building the notebook:

1. Validate it runs without errors:
```bash
cd /home/claude && jupyter nbconvert --to notebook --execute [company]_analysis.ipynb --output [company]_analysis_executed.ipynb 2>&1 | tail -20
```

2. If execution fails, debug and fix the cells.

3. Copy to outputs:
```bash
cp /home/claude/[company]_analysis.ipynb /mnt/user-data/outputs/[company]_lithium_analysis.ipynb
```

4. Use `present_files` to share the notebook.

5. Tell the user:
   - What data sources were used
   - Which figures were estimated vs sourced
   - Key assumptions to review in Section 0 (the config cell)
   - How to run it: `jupyter notebook [file].ipynb`

---

## Data Quality Notes

Always be transparent about data confidence:
- **High confidence**: ASX/SEC filings, NI 43-101 reports, audited financials
- **Medium confidence**: Investor presentations, analyst reports, press releases
- **Estimated**: Items Claude inferred or interpolated — flag these with `# ESTIMATED` comments in notebook cells

If critical data is missing (e.g. no public reserve estimate), use conservative assumptions and flag clearly. Never fabricate financial figures — use placeholders with `TODO` if needed.

---

## References

- `references/notebook_template.md` — Full `nbformat` cell templates and boilerplate code
- `references/lithium_market_context.md` — Static background on lithium types, pricing benchmarks, royalty norms by jurisdiction
